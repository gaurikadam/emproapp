package com.example.swaleha.empro;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Spinner;

import com.example.swaleha.empro.model.PersonalDetails;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class WorkStatsActivity extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;

    EditText yearedt;
    GridView gridView;
    Button btn;

    String yearvalue;
    int a=0,count=0,finaldaysabsent=0;

    Calendar cal = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_stats);

        yearedt = findViewById(R.id.yearedt);
        yearvalue = yearedt.getText().toString();
        gridView = findViewById(R.id.gridv);
        btn = findViewById(R.id.showbtn);

        final List<PersonalDetails> mDataDetails = new ArrayList<>();


        firebaseAuth = FirebaseAuth.getInstance();
        user = FirebaseAuth.getInstance().getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference().child(user.getUid());

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot ds : dataSnapshot.getChildren()) {
                            if(ds.getKey().matches(".*"+yearvalue)) {
                                if (ds.getKey().matches(".*-03-.*")) {
                                    count = count+1;
                                    Integer b = new Integer(ds.getValue().toString());
                                    if (b==8) {
                                        a += 1000;
                                    }
                                    else if(b>=4 && b<=7) {
                                        a += 500;
                                    }
                                    else {
                                        a += 0;
                                    }

                                    String datetominus = new SimpleDateFormat("MM").format(cal.getTime()).toString();
                                    Integer datetominusint = new Integer(datetominus);
                                    finaldaysabsent = datetominusint - count;
                                }
                            }

                        }
                        PersonalDetails data = dataSnapshot.getValue(PersonalDetails.class);
                        PersonalDetails pd = new PersonalDetails(data.getLeavesused(),data.getHolidays(),
                                data.getPendingsick(),data.getPendingcasual(),count,finaldaysabsent,a);
                        mDataDetails.add(pd);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });

        gridView.setAdapter(new WorkStatsAdapter(this, mDataDetails));

    }
}
